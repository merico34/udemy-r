################################################
#####         Arrays and Matrices          #####
################################################

########### EXERCISE FOR TODAY #################
# See the BestFirstTutorial PDF in documentation.
# Read and Execute Matrix Scripts pages 6-8 and
# complete the exercises beginning on page 8.
################################################
